package com.example.liamstickney.stickney_liam_f.model;

import android.arch.persistence.room.ColumnInfo;
import android.arch.persistence.room.Entity;
import android.arch.persistence.room.Ignore;
import android.arch.persistence.room.PrimaryKey;

/**
 * Created by liamstickney on 2018-12-07.
 */


@Entity (tableName = "avenger_table")
public class Avenger {

    @PrimaryKey (autoGenerate = true)
    @ColumnInfo (name = "_id")
    private long avengerId;
    private String name;

    public long getAvengerId() {
        return avengerId;
    }

    public void setAvengerId(long avengerId) {
        this.avengerId = avengerId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Avenger(long avengerId, String name) {
        this.avengerId = avengerId;
        this.name = name;
    }

    @Ignore
    public Avenger(String name) {
        this.name = name;
    }


}
