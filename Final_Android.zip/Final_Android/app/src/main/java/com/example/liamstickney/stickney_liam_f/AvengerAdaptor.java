package com.example.liamstickney.stickney_liam_f;

import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.ViewGroup;
import android.widget.TextView;

import com.example.liamstickney.stickney_liam_f.model.Avenger;



import java.util.List;

/**
 * Created by liamstickney on 2018-12-07.
 */

public class AvengerAdaptor extends RecyclerView.Adapter<AvengerAdaptor.MyViewHolder> {

    private List<Avenger> avengers;

    public AvengerAdaptor(List<Avenger> avengers) {
        this.avengers = avengers;
    }

    public static class MyViewHolder extends RecyclerView.ViewHolder {
        private TextView txtAvengerInfo;

        public MyViewHolder(@NonNull TextView itemView) {
            super(itemView);
            txtAvengerInfo = itemView;
        }
    }


    @NonNull
    @Override
    public AvengerAdaptor.MyViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int viewType) {
        TextView txtAvenger = (TextView) LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.textview_avenger,
        viewGroup, false);

        MyViewHolder holder = new MyViewHolder(txtAvenger);

        return holder;
    }

    @Override
    public void onBindViewHolder(@NonNull AvengerAdaptor.MyViewHolder myViewHolder, int i) {
        String format = "%d, %s";

        Avenger avenger = avengers.get(i);

        String toDisplay = String.format(format, avenger.getAvengerId(), avenger.getName());

        myViewHolder.txtAvengerInfo.setText(toDisplay);
    }

    @Override
    public int getItemCount() {
        if (avengers != null) {
            return avengers.size();
        } else {
            return 0;
        }
    }
}
