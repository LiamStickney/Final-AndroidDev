package com.example.liamstickney.stickney_liam_f.db;

import android.arch.persistence.room.Database;
import android.arch.persistence.room.Room;
import android.arch.persistence.room.RoomDatabase;
import android.content.Context;

import com.example.liamstickney.stickney_liam_f.model.Avenger;

/**
 * Created by liamstickney on 2018-12-07.
 */

@Database(entities = {Avenger.class}, version = 1)
public abstract class AvengerRoomDatabase extends RoomDatabase {

    private static AvengerRoomDatabase INSTANCE;

    public abstract AvengerDao avengerDao();

    public static AvengerRoomDatabase getDatabase(Context context) {
        if (INSTANCE == null) {
            INSTANCE = Room.databaseBuilder(context, AvengerRoomDatabase.class,
                    "avanger_db").build();
        }
        return INSTANCE;
    }
}
