package com.example.liamstickney.stickney_liam_f;

import android.app.Activity;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v7.widget.DividerItemDecoration;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import com.example.liamstickney.stickney_liam_f.db.AvengerDao;
import com.example.liamstickney.stickney_liam_f.db.AvengerRoomDatabase;
import com.example.liamstickney.stickney_liam_f.model.Avenger;

import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLConnection;
import java.util.List;
import java.util.Scanner;

public class MainActivity extends Activity {

    private RecyclerView recAvengers;
    EditText edtName;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        deleteAvengers();

        recAvengers = findViewById(R.id.recAvengers);
        edtName = findViewById(R.id.edtName);

        recAvengers.addItemDecoration(new DividerItemDecoration(recAvengers.getContext(), DividerItemDecoration.VERTICAL));

        RecyclerView.LayoutManager manager = new LinearLayoutManager(this, LinearLayoutManager.VERTICAL, false);

        recAvengers.setLayoutManager(manager);

        loadAvengersFromFile();

        findViewById(R.id.btnLoad).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                loadAvengersFromFile();
            }
        });

        findViewById(R.id.btnAdd).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                addAvenger();
            }
        });

        findViewById(R.id.btnDelete).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                deleteAvengers();
            }
        });



    }

    private void deleteAvengers() {
        MyDeleteTask myTask = new MyDeleteTask();
        myTask.execute();
    }

    private void addAvenger() {

        if (edtName.length() == 0) {
            edtName.setError("Name is required");
            return;
        } else {
            String name = edtName.getText().toString();

            edtName.setText("");

            Avenger avenger = new Avenger(name);

            AddTask myTask = new AddTask();

            myTask.execute(avenger);
        }
    }

    private void loadAvengersFromFile() {
        MyDeleteTask myDeleteTask = new MyDeleteTask();
        myDeleteTask.execute();

        LoadTask myTask = new LoadTask();
        myTask.execute("http://bonenfan.dev.fast.sheridanc.on.ca/avengers.txt");
    }

    private void displayAvengers() {
        RetrieveTask myTask = new RetrieveTask();

        myTask.execute();

    }

    private class RetrieveTask extends AsyncTask<Void, Void, List<Avenger>> {

        @Override
        protected List<Avenger> doInBackground(Void... voids) {
            AvengerRoomDatabase db = AvengerRoomDatabase.getDatabase(getApplicationContext());

            AvengerDao dao = db.avengerDao();

            List<Avenger> avengers = dao.getAllAvengers();

            return avengers;
        }

        @Override
        protected void onPostExecute(List<Avenger> avengers) {
            AvengerAdaptor adaptor = new AvengerAdaptor(avengers);
            recAvengers.setAdapter(adaptor);
        }
    }

    private class LoadTask extends AsyncTask<String, Void, Void> {
        @Override
        protected Void doInBackground(String... strings) {
            try {
                URL url = new URL(strings[0]);

                URLConnection conn = url.openConnection();
                HttpURLConnection httpConn = (HttpURLConnection) conn;

                int responseCode = httpConn.getResponseCode();
                if (responseCode == HttpURLConnection.HTTP_OK) {
                    InputStream is = httpConn.getInputStream();

                    Scanner scanner = new Scanner(is);

                    StringBuilder builder = new StringBuilder();

                    while (scanner.hasNextLine()) {
                        builder.append(scanner.nextLine() + "\n");
                    }

                    String[] avengersList = builder.toString().split("\n");

                    for (int i = 0; i < avengersList.length; i++) {
                        Avenger avenger = new Avenger(avengersList[i].toString());

                        AvengerRoomDatabase db = AvengerRoomDatabase.getDatabase(getApplicationContext());

                        AvengerDao dao = db.avengerDao();

                        dao.insert(avenger);
                    }

                    displayAvengers();

                } else {
                    return null;
                }
            } catch (Exception e) {
                Log.e("Error", "Exception occurred...");
            }
            return null;
        }

    }

    private class AddTask extends AsyncTask<Avenger, Void, Long> {

        @Override
        protected Long doInBackground(Avenger... avengers) {
            AvengerRoomDatabase db = AvengerRoomDatabase.getDatabase(getApplicationContext());

            AvengerDao dao = db.avengerDao();

            long id = dao.insert(avengers[0]);
            return id;


        }

        @Override
        protected void onPostExecute(Long aLong) {
            Toast.makeText(MainActivity.this, "Avenger added with id: " + aLong, Toast.LENGTH_LONG).show();

            displayAvengers();
        }
    }

    private class MyDeleteTask extends AsyncTask<Void, Void, Integer> {

        @Override
        protected Integer doInBackground(Void... voids) {
            AvengerRoomDatabase db = AvengerRoomDatabase.getDatabase(getApplicationContext());
            AvengerDao dao = db.avengerDao();

            int numRowsDeleted;

            numRowsDeleted = dao.deleteAll();

            return numRowsDeleted;

        }

        @Override
        protected void onPostExecute(Integer numRowsDeleted) {
            String format = "%d rows deleted";
            Toast.makeText(getApplicationContext(), String.format(format, numRowsDeleted), Toast.LENGTH_LONG).show();
            displayAvengers();
        }
    }
}
