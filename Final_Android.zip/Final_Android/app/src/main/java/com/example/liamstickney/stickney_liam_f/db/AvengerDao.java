package com.example.liamstickney.stickney_liam_f.db;

import android.arch.persistence.room.Dao;
import android.arch.persistence.room.Delete;
import android.arch.persistence.room.Insert;
import android.arch.persistence.room.Query;

import com.example.liamstickney.stickney_liam_f.model.Avenger;

import java.util.List;

/**
 * Created by liamstickney on 2018-12-07.
 */

@Dao
public interface AvengerDao {

    @Insert
    long insert(Avenger avenger);

    @Query("SELECT * FROM avenger_table ORDER BY name")
    List<Avenger> getAllAvengers();

    @Query("DELETE FROM avenger_table")
    int deleteAll();

    @Delete
    int delete(Avenger avenger);
}
